package bridge;

public interface MultImpl {
    int mult(int first, int second);
}
