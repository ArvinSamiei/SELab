package bridge;

public class RegMultImpl implements MultImpl {
    @Override
    public int mult(int first, int second) {
        return first * second;
    }
}
